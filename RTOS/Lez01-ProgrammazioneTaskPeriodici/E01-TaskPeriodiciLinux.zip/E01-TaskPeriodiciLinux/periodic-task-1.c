#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>

static long next_period;
static int period;

void wait_next_activation(void)
{
    struct timeval t1;
	gettimeofday(&t1,NULL);
	long now = t1.tv_sec*1000000+t1.tv_usec;
	long delay = next_period - now;
	next_period += period;
	if (delay<0) printf("delay: %ld\n",delay);
	usleep(delay);
}

void start_periodic_timer(uint64_t offs, int t)
{
	struct timeval t1;
	gettimeofday(&t1,NULL);
	long now = t1.tv_sec*1000000+t1.tv_usec;
	next_period = now + offs;
    period = t;

}

static void job_body(void)
{
    static int cnt;
    static uint64_t start;
    uint64_t t;
    struct timeval tv;

    if (start == 0) {
        gettimeofday(&tv, NULL);
		start = tv.tv_sec * 1000ULL + tv.tv_usec / 1000ULL; //ms
    }
        
    gettimeofday(&tv, NULL);
    t = tv.tv_sec * 1000ULL + tv.tv_usec / 1000ULL;
    if (cnt && (cnt % 100) == 0) {
        printf("Avg time: %f\n", (double)(t - start) / (double)cnt);
    }
    cnt++;
}

int main()
{
    start_periodic_timer(2000000, 10000);

    while(1) {
        wait_next_activation();
        job_body();
    }

    return 0;
}


