#ifndef _HEADER_
#define _HEADER_

#include <pthread.h>

#define DIM 3

typedef struct {

    int buffer[DIM];

    /* TBD: Aggiungere le variabili di stato per l'algoritmo del pool di buffer */

    /* TBD: Aggiungere le variabili per la sincronizzazione dei thread */

} VettoreProdCons;

typedef struct {

    int buffer;

    /* TBD: Aggiungere un mutex per la mutua esclusione */
    
} BufferMutuaEsclusione;

void inizializza_vettore(VettoreProdCons * p);
void produci(VettoreProdCons * p, int valore);
int consuma(VettoreProdCons * p);
void rimuovi_vettore(VettoreProdCons * p);

void inizializza_buffer(BufferMutuaEsclusione * p);
void aggiorna(BufferMutuaEsclusione * p, int valore);
void rimuovi_buffer(BufferMutuaEsclusione * p);


#endif
