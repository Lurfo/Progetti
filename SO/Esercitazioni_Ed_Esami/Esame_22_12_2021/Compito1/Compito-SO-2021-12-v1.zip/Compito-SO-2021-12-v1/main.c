#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "header.h"

#define NUM_PRODUTTORI 2
#define NUM_CONSUMATORI 5

#define PRODUZIONI 10
#define CONSUMAZIONI 4

void * produttore(void *);
void * consumatore(void *);

typedef struct {

    /* TBD: Completare questa struttura dati, per il passaggio
     *      dei parametri ai thread consumatori
     */

} parametri_consumatore;

int main() {


    VettoreProdCons * vettore = /* TBD: Allocare la struttura dati */;

    BufferMutuaEsclusione * buffer = /* TBD: Allocare la struttura dati */;


    srand(getpid());

    inizializza_vettore(vettore);

    inizializza_buffer(buffer);


    for(int i=0; i<NUM_PRODUTTORI; i++) {

        /* TBD: Creare i thread produttori, passandogli
         *      in ingresso la variabile "vettore"
         */
    }


    for(int i=0; i<NUM_CONSUMATORI; i++) {

        /* TBD: Creare i thread consumatori, passandogli
         *      in ingresso le variabili "vettore" e "buffer"
         *      mediante la struttura "parametri_consumatore"
         */
    }


    /* TBD: Attendere la terminazione dei thread produttori e dei
     *      thread consumatori
     */


    rimuovi_buffer(buffer);
    rimuovi_vettore(vettore);
    
    
    /* TBD: Deallocare le strutture dati */

    return 0;

}

void * produttore(void * p) {

    for(int i=0; i<PRODUZIONI; i++) {

        int valore = rand() % 10;

        printf("[MAIN PRODUTTORE] Produzione: %d\n", valore);

        /* TBD: Invocare il metodo "produci()" */
    }

    return NULL;
}

void * consumatore(void * p) {

    for(int i=0; i<CONSUMAZIONI; i++) {

        int valore;

        valore = /* TBD: Invocare il metodo "consuma()" */

        printf("[MAIN CONSUMATORE] Consumazione: %d\n", valore);

        /* TBD: Invocare il metodo "aggiorna()", passandogli
         *      in ingresso il valore che è stato appena consumato
         */
    }

    return NULL;
}