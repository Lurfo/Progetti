#include <stdio.h>
#include <unistd.h>

#include "header.h"

void inizializza_vettore(VettoreProdCons * p) {

    /* TBD: Inizializzare la struttura dati "VettoreProdCons" */
}

void produci(VettoreProdCons * p, int valore) {

    int indice = 0;

    /* TBD: Aggiungere la sincronizzazione, mediante l'algoritmo del 
     *      produttore-consumatore con pool di buffer
     */

    p->buffer[indice] = valore;
    sleep(1);

    printf("[PRODUCI] Produzione effettuata: %d\n", valore);

}

int consuma(VettoreProdCons * p) {

    int valore;

    int indice = 0;

    /* TBD: Aggiungere la sincronizzazione, mediante l'algoritmo del 
     *      produttore-consumatore con pool di buffer
     */

    valore = p->buffer[indice];
    sleep(1);

    printf("[CONSUMA] Consumazione effettuata: %d\n", valore);


    return valore;

}

void rimuovi_vettore(VettoreProdCons * p) {

    /* TBD: De-inizializzare la struttura dati "VettoreProdCons" */
}


void inizializza_buffer(BufferMutuaEsclusione * p) {

    /* TBD: Inizializzare la struttura dati "BufferMutuaEsclusione" */

}

void aggiorna(BufferMutuaEsclusione * p, int valore) {

    /* TBD: Effettuare la modifica al buffer in mutua esclusione */

    p->buffer += valore;

    printf("[AGGIORNA] Nuovo valore del buffer: %d\n", p->buffer);

}

void rimuovi_buffer(BufferMutuaEsclusione * p) {

    /* TBD: De-inizializzare la struttura dati "BufferMutuaEsclusione" */
}


