#ifndef _HEADER_
#define _HEADER_

#include <pthread.h>

/* TBD: Definire qui una struttura dati per i messaggi */

typedef struct {

    int valore;
    
    /* TBD: Estendere questa struttura, in modo da realizzare la 
     *      mutua esclusione per l'accesso al valore
     */

} BufferMutuaEsclusione;

#endif
