#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "header.h"

#define NUM_CLIENT 2

int main() {


    int id_coda = /* TBD: Allocare una coda di messaggi */


    for(int i=0; i<NUM_CLIENT; i++) {

        /* TBD: Creare i processi figli "client", e
         *      fargli eseguire il programma "main_client"
         */
    }


    /* TBD: Creare i processi figli "client", e
     *      fargli eseguire il programma "main_client"
     */


    /* TBD: Attendere la terminazione dei processi figli */

    /* TBD: De-allocare la coda di messaggi */


    return 0;

}
