#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <pthread.h>

#include "header.h"

#define NUM_MESSAGGI_DA_INVIARE 5

int main() {

    int id_coda = /* TBD: Accedere alla coda di messaggi allocata dal processo padre */


    srand(getpid());
    
    for(int i=0; i<NUM_MESSAGGI_DA_INVIARE; i++) {

        int valore = rand() % 10;

        printf("[CLIENT] Invio: %d\n", valore);

        /* TBD: Inviare il valore tramite un messaggio */
    }

    return 0;

}
