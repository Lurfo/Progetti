#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <pthread.h>

#include "header.h"

#define NUM_MESSAGGI_DA_RICEVERE 10

void * worker(void *);

typedef struct {

    int valore;
    BufferMutuaEsclusione * buffer;

} parametri_worker;

int main() {

    int id_coda = /* TBD: Accedere alla coda di messaggi allocata dal processo padre */



    BufferMutuaEsclusione * buffer = /* TBD: Allocare la struttura dati da condividere con i thread worker */

    buffer->valore = 0;
    /* TBD: Completare l'inizializzazione di "buffer" */


    /* Il programma avvierà un thread worker distinto 
     * per ogni messaggio ricevuto
     */
    pthread_t thread_worker[NUM_MESSAGGI_DA_RICEVERE];

    for(int i=0; i<NUM_MESSAGGI_DA_RICEVERE; i++) {

        /* TBD: Effettuare la ricezione del messaggio */


        printf("[SERVER] Ricezione: %d\n", /* TBD */);


        /* TBD: Creare un thread figlio, facendogli eseguire la
         *      funzione "worker", e passandogli sia il valore ricevuto
         *      sia il "buffer", tramite la struttura dati "parametri_worker"
         */        
    }


    /* TBD: Attendere la terminazione dei thread figli */


    /* TBD: De-allocazione della struttura dati "buffer" */


    return 0;

}


void * worker(void * p) {

    BufferMutuaEsclusione * buffer = /* TBD: Completare il passaggio dei parametri */;
    int valore = /* TBD: Completare il passaggio dei parametri */;


    /* TBD: Effettuare la modifica del buffer in mutua esclusione */

    sleep(1);

    buffer->valore += valore;

    printf("[WORKER] Nuovo valore del buffer: %d\n", buffer->valore);


    return NULL;
}